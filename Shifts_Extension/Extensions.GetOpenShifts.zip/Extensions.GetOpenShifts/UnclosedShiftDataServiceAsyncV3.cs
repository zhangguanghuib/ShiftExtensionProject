﻿namespace Contoso
{
    namespace Commerce.Runtime.GetOpenShifts
    {
        using System;
        using Microsoft.Dynamics.Commerce.Runtime;
        using Microsoft.Dynamics.Commerce.Runtime.DataModel;
        using Microsoft.Dynamics.Commerce.Runtime.Messages;
        using Microsoft.Dynamics.Commerce.Runtime.RealtimeServices.Messages;
        using System.Collections.ObjectModel;
        using System.Threading.Tasks;

        public class UnclosedShiftDataServiceAsyncV3
        {
            public static void CreateShiftAsync(CreateShiftRequest request, CreateShiftResponse response)
            {
                ThrowIf.Null(request, "CreateShiftRequest");
                ThrowIf.Null(response, "CreateShiftResponse");

                string inventLocationDataAreaId = request.RequestContext.GetChannelConfiguration().InventLocationDataAreaId;

                Task.Run<bool>(() => {
                    InvokeExtensionMethodRealtimeRequest extensionRequest = new InvokeExtensionMethodRealtimeRequest(
                        "CreateNewShift",
                        response.Shift.StoreRecordId,
                        response.Shift.TerminalId,
                        response.Shift.StoreId,
                        response.Shift.ShiftId,
                        response.Shift.StaffId,
                        response.Shift.CurrentStaffId,
                        Convert.ToInt32(response.Shift.Status),
                        response.Shift.CurrentTerminalId,
                        response.Shift.IsShared,
                        response.Shift.CashDrawer,
                        inventLocationDataAreaId);

                    InvokeExtensionMethodRealtimeResponse RTSResponse = request.RequestContext.Execute<InvokeExtensionMethodRealtimeResponse>(extensionRequest);
                    ReadOnlyCollection<object> results = RTSResponse.Result;
                    bool success = Convert.ToBoolean(results[0]);
                    return success;
                });
            }

            public static void CloseShiftAsync(Shift shift, Request request)
            {
                Task.Run<bool>(() =>
                {
                    InvokeExtensionMethodRealtimeRequest extensionRequest = new InvokeExtensionMethodRealtimeRequest(
                       "RemoveOpenedShift",
                       shift.StoreRecordId,
                       shift.TerminalId,
                       shift.ShiftId);
                    InvokeExtensionMethodRealtimeResponse RTSResponse = request.RequestContext.Execute<InvokeExtensionMethodRealtimeResponse>(extensionRequest);
                    ReadOnlyCollection<object> results = RTSResponse.Result;
                    bool success = Convert.ToBoolean(results[0]);
                    return success;
                });
            }

            public static void ChangeShiftStatusAsync(Shift shift, Request request)
            {
                Task.Run<bool>(() => {
                    InvokeExtensionMethodRealtimeRequest extensionRequest = new InvokeExtensionMethodRealtimeRequest(
                       "ChangeShiftStatus",
                       shift.StoreRecordId,
                       shift.TerminalId,
                       shift.ShiftId,
                       Convert.ToInt32(shift.Status),
                       shift.CurrentTerminalId,
                       shift.CurrentStaffId);

                    InvokeExtensionMethodRealtimeResponse RTSResponse = request.RequestContext.Execute<InvokeExtensionMethodRealtimeResponse>(extensionRequest);
                    ReadOnlyCollection<object> results = RTSResponse.Result;
                    bool success = Convert.ToBoolean(results[0]);
                    return success;
                });
            }
        }
    }
}

