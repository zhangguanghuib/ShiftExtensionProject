﻿using System;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]

// Request/Response is not CLS-compliant
[assembly: CLSCompliant(false)]